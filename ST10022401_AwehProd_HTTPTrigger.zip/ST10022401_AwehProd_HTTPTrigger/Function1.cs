using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace ST10022401_AwehProd_HTTPTrigger
{
    public static class Function1
    {
        [FunctionName("Function1")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string year = req.Query["name"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            year = year ?? data?.year;

            int yearInt;
            
            if (int.TryParse(year, out yearInt))
            {
                string generation = GenerateGeneration(yearInt);
                string responsMessage = $"Hello, " + generation;
                return new OkObjectResult(responsMessage);
            }
            else
            {
                string responsMessage = $"Welcome to the generation tracker!\n Please enter your year of birth in theURL e.g. ?year=1990";
                return new BadRequestObjectResult(responsMessage);
            }
        }

        public static string GenerateGeneration(int year)
        {
            if (year <= 1900) return "Your generation is dead";
            if (year <= 1927) return "You are part of the greatest generation";
            if (year <= 1945) return "You are the silent generation";
            if (year <= 1964) return "You are part of the baby boomer generation";
            if (year <= 1980) return "You are generation X";
            if (year <= 1996) return "You are generation Milennial";
            if (year <= 2012) return "You are generation Z";
            if (year <= 2025) return "You are generation Alpha";

            return "What Generation are you? Please enter your year of birth.";
        }
    }



}
